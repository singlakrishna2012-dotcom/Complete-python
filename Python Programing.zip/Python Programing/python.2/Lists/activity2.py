def match_word(words):
    ctr = 0
    lst = []
    for word in words:
        if len(words) > 1 and word[0] == word[-1]:
            ctr += 1
            lst.append(word)
    print("List of words with same first and last letter are ", lst)
    return ctr
count = match_word([1221, "abcba", 99, "xyxyx", "Krishna"])
print(count)
