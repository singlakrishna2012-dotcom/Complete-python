lis = []
print(lis)

lis = [1, 3, "Krishna", 2012, "Punjab"]
print(lis)

lis = [1, 4, 9, 16, 25]
tlis = [1, 4, 9, 16, 25] * 3
print(f"triple of {lis} = {tlis}")
rlis = tlis[::-1]
print(f"reverse of {tlis} = {rlis}")
