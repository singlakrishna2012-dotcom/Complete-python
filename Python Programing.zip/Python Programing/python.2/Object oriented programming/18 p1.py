class IOString:
    def __int__(self):
       self.str1 = " "
    def gets(self):
        self.str1 = input("Enter the string : ")
    def result(self):
        print("String in upper case = ", self.str1.upper())

str1 = IOString()

str1.gets()
str1.result()
