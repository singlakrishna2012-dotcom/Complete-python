from abc import ABC, abstractmethod

class Animal(ABC):
    def move(self):
        pass

class human(Animal):
    def move(self):
        print("I can walk")
class snake(Animal):
    def move(self):
        print("I can crawl")
class dog(Animal):
    def move(self):
        print("I can bark")
class lion(Animal):
    def move(self):
         print("I can roar")


h =human()
h.move
s = snake()
s.move
d = dog()
d.move
l = lion()
l.move