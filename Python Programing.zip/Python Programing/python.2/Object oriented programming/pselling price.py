class comp:
    def __init__(self):
        self.__mrp = 900

    def sell(self):
        print("Selling price = ", self.__mrp)

    def update(self, price):
        self.__mrp = price

c = comp()
c.sell()
c.__mrp = 1000
c.sell()

c.update(1000)
c.sell()