from abc import ABC , abstractmethod
class abs(ABC):
    def print(self, x):
        print("Passed value of x is", x)

    @abstractmethod
    def task(self):
        print("Inside ads class")

class test(abs):
    def task(self):
        print("Inside the test class")


obj = test()
obj.task()
obj.print(100)