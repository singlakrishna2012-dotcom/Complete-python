class Parrot:
    species = "Bird"
    def __init__(self, name, age):
        self.name = name
        self.age = age

n1 = input(("Enter the name of the first bird - "))
a1 = int(input("Enter the age of your first bird - "))

bird1 = Parrot(n1, a1)

n2 = input(("Enter the name of the second bird - "))
a2 = int(input("Enter the age of your second bird - "))

bird2 = Parrot(n2, a2)

print(f"Species of {n1} is {format(bird1.species)}")
print(f"Species of {n2} is {format(bird2.species)}")

print(f"Age of {n1} is {format(bird1.age)}")
print(f"Age of {n2} is {format(bird2.age)}")