class Student:
    grade = 10
    print(f"My class is {grade}")

od = Student()