class myclass:
    __myvar = "krishna"

    def __myvar(self):
        print("My name is ", myclass.__myvar)

    def name(self):
       print("My name is ", myclass.__myvar)


foo = myclass()
foo.__myvar
foo.name