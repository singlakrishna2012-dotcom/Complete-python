class FamilyMember :
    def __init__(self, eye_color, height):
        self.eye_color = eye_color
        self.height = height

    def traits(self):
        print("Eye Colour - ", self.eye_color)
        print("Height - ", self.height)

class kid(FamilyMember):
    def __init__(self, name, age, eye_color, height):
        self.name = name
        self.age = age
        super().__init__(eye_color, height)

    def traits(self):
        print("Name - ", self.name)
        print("Age - ", self.age)
        super().traits()

    def hobby(self, hobby):
        print(f"{self.name} love {hobby}")

child = kid("MAYA", 20, "Brown", 170)

child.traits()
child.hobby("Singing")

print("Is kid a sub class of FamilyMember ?  --", issubclass(kid, FamilyMember))