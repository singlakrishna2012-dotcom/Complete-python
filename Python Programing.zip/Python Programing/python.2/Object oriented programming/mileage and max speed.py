class Vehichle:
    def __init__(self, max, mileage):
        self.milage = mileage
        self.max = max

modelLX = Vehichle(280, 8)

print("Max speed of vehichle is ", modelLX.max)
print("Mileage of the vehichle is - ", modelLX.milage)