class Emp:
    def __init__(self):
        print("Emloyee created : ")
    def __del__(self):
        print("employee destructed ; ")

def pri():
    print("creating object ; ")
    obj = Emp()
    print("Function End ....")
    return obj

print("Calling Create Object the function")
obj = pri()
print("Function end .....")