class Book:
    is_borrowed = False
    def borrow(self, book):
        self.book = book
        self.is_borrowed = True
        print(f"Book {self.book} has been borrowed")

    def return_book(self, book):
        self.book = book
        if self.is_borrowed == True:
            self.is_borrowed == False
            print(f"Thank you for returning the book '{self.book}' on time")
        elif self.is_borrowed == False:
            print("The book has not been bought, so it cant be returned")
            pass

b = Book()

b.borrow("Harry Potter")
b.return_book("Harry Potter")
b.borrow("Bad Guys")
b.borrow("The end Game: Avengers")
b.return_book("Bad Guys")
b.return_book("The end Game: Avengers")