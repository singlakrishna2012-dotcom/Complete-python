basket1 = {"apple", "bannana", "mango", "watermelon"}
basket2 = {"mango", "apple", "kiwi", "gauva"}

print(f"basket 1 = {basket1}\nbasket2 = {basket2}")
basket1.add("orange")
print(f"Updated basket 1 = {basket1}")

cm = basket1.intersection(basket2)
print("fruits common in basket 1 and basket 2 are ", cm)

import array as arr

counts = arr.array('i', [3,5,7,6])
print("counts of fruits = ", counts)

counts.insert(1, 0)
counts.append(5)
print("updated fruit count = ", counts)

count4 = counts.count(4)
print(f"number of fruits that are 4 in number are {counts}")

print("========CLASS FRUIT BASKET ORGANIZER========")
print(f"Basket 1 : {basket1}\nBasket 2 : {basket2}\nCommon Fruits : {cm}\nFruit Count : {counts}")
print("============================================")