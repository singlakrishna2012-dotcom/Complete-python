try:
    num1, num2 = eval(input("Enter 2 numbers seperated by a comma :"))
    result = int(num1) / int(num2)
    print("Result = ", result)
except ZeroDivisionError:
    print("The second number shoul not be zero")
except SyntaxError:
    print(SyntaxError)
    # print("Seperate numbers using comma , example - 1, 2")
except:
    print("Wrong input!!!!")
else:
    print("no error")
finally:
    print("this execution does not matter")
