try:
    num = int(input("Enter a number ; "))
    print("entered number is ", num)
except ValueError:
    print("error => ", ValueError)