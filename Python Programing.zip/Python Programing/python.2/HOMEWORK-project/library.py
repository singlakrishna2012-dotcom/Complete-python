items = ["Comics", "Fantasy", "Sci-Fi", "Horror", "Magzines"]
stock = [20, 0, 9, 12, 5]

inventory = {item: count for item, count in zip(items, stock)}
print(f"Full Library : {inventory}")

available = [item for item in items if inventory[item] > 0]
print(f"Books in stock are {available}")

buy = input("Which book do you want to buy? =>. ")
if buy not in inventory or inventory[buy] == 0:
    print("out of stock")
    exit()

prices = [20, 40, 5, 30, 80]
markup = int(input("Enter the markup amoun to add every price ; "))

updates = list(map(lambda p : p + markup, prices))
print("Mark up prices : ", updates)

inde = items.index(buy)
chosen = prices[inde]
print(f"price of {buy} is ", chosen)

inventory[buy] -= 1
print(f"Remaining stock of {buy} is {inventory[buy]}")

print("===============INVENTORY CHECKER===============")
print("Book Bought :", buy)
print("Price Paid :", chosen)
print("updated Library :", inventory)