bill = int(input("enter the bill amount :   "))
days = int(input("Enter the due days :  "))
due = int(input("Enter the due per day :    "))
def total(x, y, z):
    return x + (x * y / 100) * z
print("Total amount to be paid = ", total(bill, days, due))