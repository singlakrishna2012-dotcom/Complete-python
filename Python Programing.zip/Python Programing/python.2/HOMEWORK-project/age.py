try :
    age = int(input("Enter your age"))
    if age < 1:
        print("invalid age.")
    elif age >= 1 and age % 2 == 0:
        print("Your age is even")
    else :
        print("It is an odd age")
except:
    print("value error!!!")