import random
import math

# Generate a random angle between 0 and 360 degrees
angle = random.randint(0, 360)

# Convert degrees to radians
radian = math.radians(angle)

# Print the angle and its trigonometric values
print("Random Angle:", angle, "degrees")
print("sin =", math.sin(radian))
print("cos =", math.cos(radian))
print("tan =", math.tan(radian))