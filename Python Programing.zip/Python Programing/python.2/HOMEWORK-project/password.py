import random
import string

# Characters to choose from
chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"

# Generate 12 character password
password = ""
for i in range(12):
    password += random.choice(chars)

print("Password:", password)