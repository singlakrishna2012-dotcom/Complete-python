students = {
    "Krishna": {"maths": 40, "science": 30, "sst": 40},
    "Simran": {"maths": 29, "science": 36, "sst": 20},
    "Lalit": {"maths": 20, "science": 30, "sst": 40},
    "Savya": {"maths": 40, "science": 38, "sst": 39},
    "Mukesh": {"maths": 25, "science": 20, "sst": 40},
}

student_totals = {}
for name, marks in students.items():
    total = sum(marks.values())
    student_totals[name] = total
    print(f"{name}: {total}")

class_total = sum(student_totals.values())
class_average = class_total / len(student_totals)

print("Max marks -", max(student_totals.values()))
print("Min marks -", min(student_totals.values()))
print("Average class marks -", class_average)