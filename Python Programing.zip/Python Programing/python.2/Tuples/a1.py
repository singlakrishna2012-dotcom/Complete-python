tuplex = (2, 5, "false", True, 98.4)
print(tuplex)
print(tuplex.count(5))
tuplex = tuplex + (9,  )
print(tuplex)
slic = tuplex[2:4]
print(slic)
slic = tuplex[:3]
