def palind(r):
    e = len(r) - 1
    s = 0
    while s < e:
        if r[s] != r[e]:
            print("NOT A PLAINDROIME")
        s += 1
        e -= 1
    return True
r = (4, 5, 9, 9, 5, 4)
print(r)
if palind(r):
    print("it is a plaindrome")
else:
    print("not a palindrome")