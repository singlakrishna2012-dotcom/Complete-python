w = input("Enter a word -  ")
s = input("Enter an alphabet - ")

for i in w:
    if (i == s):
        print(f"{s} is found in the {w}")
        break
    else:
        print(f"{s} is not foun in {w}")