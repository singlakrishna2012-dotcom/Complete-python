num = int(input("Enter a number - "))
while num > 0:
    num -= 1
    if num == 5:
        continue
    else:
        print("current variable is ", num)
print("Good bye!")