from tkinter import *
from tkinter import messagebox

root = Tk()
root.geometry("400x400")


def msg():
    messagebox.showwarning("ALERT!", "Virus Detected!!")

btn = Button(root, text='Scan for virus', command=msg)
btn.place(x=200, y=200)

root.mainloop()