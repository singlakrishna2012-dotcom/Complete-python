from tkinter import *

root = Tk()
root.title('Login App')
root.geometry('400x400')

frame = Frame(master=root, height = 200, width=350, bg = '#a0f0a0')
lbl1 = Label(frame, text = "Full Name", bg = "#a3aaf9")
lbl2 = Label(frame, text = "Email id", bg = "#a3aaf9")
lbl3 = Label(frame, text = "Enter Password", bg = "#a3aaf9")

name_entry = Entry(frame)
email_entry = Entry(frame)
pass_entry = Entry(frame, show="X")

def display():
    name = name_entry.get()
    greet = "Hey "+name
    message  = "\n Congratulations for your new account" 
    textbox.insert(END, greet)
    textbox.insert(END, message)

textbox = Text(bg="#BEBEBE", fg="black")

btn = Button(text = "CREATE ACCOUNT", command=display, bg="red")

frame.place(x=20,y=0)
lbl1.place(x=20, y=20)
name_entry.place(x=150, y=20)
lbl2.place(x=20, y=80)
email_entry.place(x=150, y=80)
lbl3.place(x=20, y=140)
pass_entry.place(x=150, y=140)
btn.place(x=130, y=210)
textbox.place(y=250)

root.mainloop()