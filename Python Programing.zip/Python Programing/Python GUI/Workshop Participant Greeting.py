from tkinter import *
from datetime import date
root = Tk()
root.title('Workshop Participant Greeting')
root.geometry('400x300')

lbl = Label(text="Workshop Participant Greeting Application", height=1, bg="#898CE5", fg="#000b9e")
name_labl = Label(text="Full Name", bg="#00093b", fg="#009aaf")
name_entry = Entry()

def display():
    name = name_entry.get().strip()
    if not name:
        text_box.delete("1.0", END)
        text_box.insert(END, "Please enter your full name.")
        return

    text_box.delete("1.0", END)
    text_box.insert(END, f"Hello {name}!\n")
    text_box.insert(END, "Welcome to the workshop participant program.\n")
    text_box.insert(END, f"Today's date is: {date.today()}")

text_box = Text(height=4, width=40)
btn = Button(text="Begin", command=display, height=1, bg="#1261A0", fg="white")

lbl.pack(fill="x", pady=(10, 15))
name_labl.pack()
name_entry.pack(pady=(5, 10))
btn.pack()
text_box.pack(pady=15)

root.mainloop()