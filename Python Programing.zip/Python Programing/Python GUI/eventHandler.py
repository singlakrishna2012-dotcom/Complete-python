from tkinter import *

window = Tk()
window.title("EVENT HANDLER")
window.geometry('100x100')

def eh(event):
    """Print the charachter assosiated to the key pressed"""
    print(event.char)

window.bind("<Key>", eh)

def hc(event):
    print("\nThe button was clicked!")

button = Button(text="Click me!")
button.pack()

button.bind("<Button-1>", hc)

window.mainloop()