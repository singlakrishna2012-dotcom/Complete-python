from tkinter import *

root = Tk()
root.geometry("400x400")
root.title("Main Window")

def topwin():
    top = Toplevel()
    top.geometry("180x180")
    top.title("Top Level Window")

    l2 = Label(top, text="This is a top level window")
    l2.pack()

    top.mainloop()

l = Label(root, text="This is a root window")
btn = Button(root, text="Top level window", command=topwin)
l.pack()
btn.pack()

root.mainloop()