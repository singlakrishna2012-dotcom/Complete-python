from tkinter import *

root = Tk()
root.title('Number Pad')
root.geometry('250x300')

nums = [[9, 8, 7] , [6, 5, 4], [3, 2, 1], ['#', 0, '*']]

for i in range (4):
    root.columnconfigure(i, weight=1, minsize=79)
    root.rowconfigure(i, weight=1, minsize=10)
    for j in range(0, 3):
        frame = Frame(
            master=root,
            relief=RAISED,
            borderwidth=1
        )
        frame.grid(row=i, column=j)
        label = Label(master=frame, text=nums[i][j], bg = "#00af69")
        label.pack(padx=1, pady=1)

root.mainloop()
